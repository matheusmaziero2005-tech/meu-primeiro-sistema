package br.com.starlog.controller;

import br.com.starlog.model.CriptoMensagem;

public class TransmissaoController {
    private int totalTransmissoes = 0;

    public String processarTransmissao(String remetente, String mensagem, String chaveStr) {
        int chave;
        try {
            chave = Integer.parseInt(chaveStr);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Chave deve ser um número válido.");
        }

        CriptoMensagem cripto = new CriptoMensagem(remetente, mensagem, chave);
        
        int checksum = cripto.calcularChecksum();
        String mensagemCifrada = cripto.cifrar();
        
        totalTransmissoes++;

        
        return String.format("[%s] #%d -> %s", cripto.getRemetente(), checksum, mensagemCifrada);
    }

    public int getTotalTransmissoes() {
        return totalTransmissoes;
    }
}