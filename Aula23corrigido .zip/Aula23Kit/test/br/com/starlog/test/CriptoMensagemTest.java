package br.com.starlog.test;

public class CriptoMensagemTest {
    private String remetente;
    private String mensagem;
    private int chave;

    public CriptoMensagemTest(String remetente, String mensagem, int chave) {
        if (remetente == null || remetente.trim().isEmpty()) {
            throw new IllegalArgumentException("Remetente não pode ser nulo ou em branco");
        }
        if (chave < 1 || chave > 25) {
            throw new IllegalArgumentException("Chave deve estar entre 1 e 25");
        }
        this.remetente = remetente;
        this.mensagem = mensagem != null ? mensagem : "";
        this.chave = chave;
    }

    public String cifrar() {
        StringBuilder resultado = new StringBuilder();

        for (int i = 0; i < mensagem.length(); i++) {
            char c = mensagem.charAt(i);

            if (c >= 'A' && c <= 'Z') {
                char cifrado = (char) (c + chave);
                if (cifrado > 'Z') {
                    cifrado = (char) (cifrado - 26); 
                }
                resultado.append(cifrado);
            } else if (c >= 'a' && c <= 'z') {
                char cifrado = (char) (c + chave);
                if (cifrado > 'z') {
                    cifrado = (char) (cifrado - 26);
                }
                resultado.append(cifrado);
            } else {
                
                resultado.append(c);
            }
        }

        return resultado.toString();
    }

    public int calcularChecksum() {
        int soma = 0;
        for (int i = 0; i < mensagem.length(); i++) {
            soma += mensagem.charAt(i);
        }
        return soma;
    }

    public String getRemetente() {
        return remetente;
    }

    public String getMensagem() {
        return mensagem;
    }

    public int getChave() {
        return chave;
    }
}